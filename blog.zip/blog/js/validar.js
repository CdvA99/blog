 
function valida_envia(){
  //validacion del campo nombre
  if (document.formulario.Nombre.value.length==0){
      alert("El campo Nombre esta vacio")
      document.formulario.Nombre.focus()
      return 0;
  } 


//validacion del campo de servicios

if(document.formulario.Telefono.value.length==0){
    alert("El campo Telefono esta vacio")
    document.formulario.Telefono.focus()
    return 0;
}

// validacion del campo e-mail

if(document.formulario.Correo.value.length==0){
    alert("El campo E-mail esta vacio")
    document.formulario.Correo.focus()
    return 0;
}


// validacion del campo Asunto

if(document.formulario.Asunto.value.length==0){
    alert("El campo Asunto esta vacio")
    document.formulario.Asunto.focus()
    return 0;
}

// validacion del campo de Mensaje

if(document.formulario.Mensaje.value.length==0){
    alert("Debes enviar un mensaje")
    document.formulario.Mensaje.focus()
    return 0;
}






//Este mensaje aparece si todos los campos son completados

  alert("Mensaje enviado");
  document.formulario.sumbit();
}




   